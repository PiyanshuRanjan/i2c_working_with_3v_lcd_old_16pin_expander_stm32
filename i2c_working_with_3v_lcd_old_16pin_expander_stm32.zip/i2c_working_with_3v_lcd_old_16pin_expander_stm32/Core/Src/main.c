/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

#define LCD_I2C_ADDR 0x70


#define LCD_ADDRESS     (0x7c>>1)

extern uint8_t _showfunction;

/*!
 *   commands
 */
#define LCD_CLEARDISPLAY 0x01
#define LCD_RETURNHOME 0x02
#define LCD_ENTRYMODESET 0x04
#define LCD_DISPLAYCONTROL 0x08
#define LCD_CURSORSHIFT 0x10
#define LCD_FUNCTIONSET 0x20
#define LCD_SETCGRAMADDR 0x40
#define LCD_SETDDRAMADDR 0x80

/*!
 *   flags for display entry mode
 */
#define LCD_ENTRYRIGHT 0x00
#define LCD_ENTRYLEFT 0x02
#define LCD_ENTRYSHIFTINCREMENT 0x01
#define LCD_ENTRYSHIFTDECREMENT 0x00

/*!
 *   flags for display on/off control
 */
#define LCD_DISPLAYON 0x04
#define LCD_DISPLAYOFF 0x00
#define LCD_CURSORON 0x02
#define LCD_CURSOROFF 0x00
#define LCD_BLINKON 0x01
#define LCD_BLINKOFF 0x00

/*!
 *   flags for display/cursor shift
 */
#define LCD_DISPLAYMOVE 0x08
#define LCD_CURSORMOVE 0x00
#define LCD_MOVERIGHT 0x04
#define LCD_MOVELEFT 0x00

/*!
 *   flags for function set
 */
#define LCD_8BITMODE 0x10
#define LCD_4BITMODE 0x00
#define LCD_2LINE 0x08
#define LCD_1LINE 0x00
#define LCD_5x8DOTS 0x00

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);


/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
HAL_StatusTypeDef i2c_check_status;

uint8_t *pdata;
uint8_t data[2] = {0xFF,0xFF};

#define ENABLE_LCD_PLUS 0x04
#define RS_LCD 0x01
#define BACK_LIGHT_LCD_ON 0x08

HAL_StatusTypeDef I2C_Expender_Write( uint8_t data8bit )
{
	data8bit = data8bit | BACK_LIGHT_LCD_ON;
	return HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, &data8bit, 1, 100);
}

void LCD_Write_CMD(uint8_t lcdcmd)
{
	uint8_t lcd_higher_nible;
	uint8_t lcd_lower_nible;
	uint8_t data8bit;

	lcd_higher_nible = lcdcmd & 0xF0;
	lcd_lower_nible = (lcdcmd << 4) & 0xF0;

	data8bit = lcd_higher_nible;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = lcd_higher_nible;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(500);

	data8bit = lcd_lower_nible;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = lcd_lower_nible;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(500);
}

void LCD_Write_ByteData(uint8_t lcddata)
{
	uint8_t lcd_higher_nible;
	uint8_t lcd_lower_nible;
	uint8_t data8bit;

	lcd_higher_nible = lcddata & 0xF0;
	lcd_lower_nible = (lcddata << 4) & 0xF0;

	data8bit = lcd_higher_nible | RS_LCD;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | RS_LCD | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = lcd_higher_nible | RS_LCD;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(500);

	data8bit = lcd_lower_nible | RS_LCD;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | RS_LCD | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = lcd_lower_nible | RS_LCD;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(500);
}

void LCD_I2C_Init()
{
	uint8_t data8bit;

	HAL_Delay(1000);
	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(1000);

	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(500);

	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = 0x30;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(200);

	//********************************************

	data8bit = 0x20;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = data8bit | ENABLE_LCD_PLUS;
	data8bit = data8bit | ENABLE_LCD_PLUS;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(100);
	data8bit = 0x20;
	I2C_Expender_Write(data8bit);
	I2C_Expender_Write(data8bit);
	HAL_Delay(50);

	//**************************************
	// Function Set
	data8bit = 0x28;
	LCD_Write_CMD(data8bit);
	HAL_Delay(500);

	// Display Control
	data8bit = 0x0f;
	LCD_Write_CMD(data8bit);
	HAL_Delay(500);

	data8bit = 0x01;
	LCD_Write_CMD(data8bit);
	HAL_Delay(500);

	data8bit = 0x80;
	LCD_Write_CMD(data8bit);
	HAL_Delay(500);

}

void LCD_I2C_Write_Char(uint8_t bytedata)
{
	LCD_Write_ByteData(bytedata);
}
int main(void)
{

  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();

  LCD_I2C_Init();
  LCD_I2C_Write_Char('A');
  LCD_I2C_Write_Char('1');
  LCD_I2C_Write_Char('G');
  LCD_I2C_Write_Char('X');
  LCD_I2C_Write_Char('$');
  LCD_I2C_Write_Char('@');


  i2c_check_status = 0x05U;
  pdata = (uint8_t *)data;

  int arr[10] = {0x00,0x00,0x01,0x02,0x04,0x10,0x20,0x40,0x80,0xf7};
  int i = 0;
    while(i < 10)
    {
    	data[0] = arr[i];
    	i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
    	i++;
    }

  //end
  data[0] = 0x2d;
 // data[1] = LCD_4BITMODE | LCD_2LINE | LCD_5x8DOTS;
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(10000);
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(5000);
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(2000);
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(1000);

  data[0] = 0x0d;
  data[1] = 0x0d;
 // data[1] = 0x0f;
// data[1] = LCD_DISPLAYOFF;
    /*data[1] = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;*/
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(10000);

  data[0] = 0x01;
  data[1] = 0x01;
  //data[1] = LCD_CLEARDISPLAY;
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(10000);

  data[0] = 0x07;
  data[1] = 0x07;
  //data[1] = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(10000);

  data[0] = 0x80;
  data[1] = 0x80;
 // data[1] = LCD_ENTRYMODESET;
  i2c_check_status = HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, pdata, 1, 100);
  HAL_Delay(10000);


  while (1)
  {
    /* USER CODE END WHILE */
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, 1);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, 0);
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


















/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00303D5B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_7B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_GREEN_Pin */
  GPIO_InitStruct.Pin = LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PC5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
